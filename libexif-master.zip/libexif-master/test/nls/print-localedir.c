/* Copyright (C) 2005-2007 Hans Ulrich Niedermann <gp@n-dimensional.de>
 * SPDX-License-Identifier: LGPL-2.0-or-later
 */

#include "config.h"
#include "libexif/i18n.h"

#include <stdio.h>

int main(void)
{
  puts(LOCALEDIR);
  puts("\n");
  return 0;
}
